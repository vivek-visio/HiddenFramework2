//
//  HiddenFramework2.h
//  HiddenFramework2
//
//  Created by Visioapps on 05/09/24.
//

#import <Foundation/Foundation.h>

//! Project version number for HiddenFramework2.
FOUNDATION_EXPORT double HiddenFramework2VersionNumber;

//! Project version string for HiddenFramework2.
FOUNDATION_EXPORT const unsigned char HiddenFramework2VersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HiddenFramework2/PublicHeader.h>


